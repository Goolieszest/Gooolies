# GOOLIES — Hydration, delivered

A water health-pack ordering app with cart, checkout, delivery tracking, purchasable
health guides, and a Claude-powered support chat widget.

## What changed from the Claude artifact version

This app started as a Claude artifact, which gives two things for free that a normal
website doesn't have:
- `window.storage` — persists cart/orders without you running a database
- Built-in Claude API access — no API key needed in the code

Outside of Claude, those don't exist, so:
- `window.storage` now falls back to the browser's `localStorage` (see the shim at the
  top of `src/App.jsx`). Good enough for a single device; if you want orders to follow
  a customer across devices, you'll eventually want a real database instead.
- The chat widget calls `/api/chat` (in `api/chat.js`), a small serverless function
  that holds your real Anthropic API key **server-side** and forwards the request.
  Never put a real API key directly in frontend code — anyone could open dev tools
  and steal it.

## 1. Run it locally

```bash
npm install
npm run dev
```

The chat widget won't work locally unless you set `ANTHROPIC_API_KEY` (see step 3) —
everything else (catalog, cart, checkout, tracking, guides) works without it.

## 2. Push to GitHub

```bash
git init
git add .
git commit -m "Initial commit"
gh repo create goolies-app --public --source=. --push
```

(Or create a repo on github.com and follow its "push an existing repo" instructions.)

## 3. Deploy on Vercel

1. Go to vercel.com, sign in, click **Add New → Project**
2. Import your GitHub repo
3. Before deploying, add an environment variable:
   - Key: `ANTHROPIC_API_KEY`
   - Value: a real key from https://console.anthropic.com (Settings → API Keys)
4. Click **Deploy**

You'll get a free `*.vercel.app` URL immediately — check that the site works before
moving on to the domain.

## 4. Connect your own domain

1. Buy a domain (Namecheap, GoDaddy, Google Domains successor, etc.) if you don't
   already have one
2. In your Vercel project, go to **Settings → Domains**, add your domain
   (e.g. `goolieswater.co.za`)
3. Vercel shows you DNS records to add (usually an A record or CNAME)
4. Go to your domain registrar's DNS settings and add those records
5. Wait for DNS to propagate (a few minutes to a few hours) — Vercel issues an SSL
   certificate automatically once it's verified

That's it — your domain now points at the live app, with HTTPS, no app store and no
Anthropic review step involved.

## Notes on payment

Card payment in this app is still a UI mockup — no real charge happens. To take real
card payments you'd add a payment processor (Stripe is the standard choice), which is
a separate integration from everything above. Cash on delivery works as-is since it
doesn't need a payment gateway.
